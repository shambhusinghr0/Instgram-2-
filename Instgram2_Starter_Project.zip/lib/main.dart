import 'package:flutter/material.dart';

void main() => runApp(const Instgram2App());

const brand = Color(0xFF8B5CF6);

class Instgram2App extends StatelessWidget {
  const Instgram2App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Instgram 2',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: brand, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF101018),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomePage(), ReelsPage(), CreatePage(), VideosPage(), ProfilePage()];
  final labels = ['Home', 'Reels', 'Create', 'Videos', 'Profile'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Instgram 2', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .2)),
        actions: [
          IconButton(onPressed: () => _message(context, 'Notifications जल्द जोड़े जाएंगे।'),
            icon: const Icon(Icons.notifications_none)),
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'Reels'),
          NavigationDestination(icon: Icon(Icons.add_box_outlined), selectedIcon: Icon(Icons.add_box), label: 'Create'),
          NavigationDestination(icon: Icon(Icons.ondemand_video_outlined), selectedIcon: Icon(Icons.ondemand_video), label: 'Videos'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

void _message(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final posts = [
      ('Aarav', 'आज का खूबसूरत नज़ारा ✨', Icons.landscape),
      ('Meera', 'नई शुरुआत, नई यादें 💜', Icons.photo_camera),
      ('Kabir', 'Weekend vibes!', Icons.music_note),
    ];
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('आपके लिए', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SizedBox(
          height: 92,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: const [
              StoryBubble(name: 'Your story', color: brand),
              StoryBubble(name: 'Aarav', color: Colors.orange),
              StoryBubble(name: 'Meera', color: Colors.pink),
              StoryBubble(name: 'Kabir', color: Colors.teal),
              StoryBubble(name: 'Isha', color: Colors.blue),
            ],
          ),
        ),
        const SizedBox(height: 8),
        for (final post in posts) Card(
          clipBehavior: Clip.antiAlias,
          color: const Color(0xFF1C1C29),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ListTile(
              leading: CircleAvatar(backgroundColor: brand.withOpacity(.25), child: Text(post.$1[0])),
              title: Text(post.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('आज'),
              trailing: const Icon(Icons.more_horiz),
            ),
            Container(
              height: 190,
              width: double.infinity,
              color: const Color(0xFF29263A),
              child: Icon(post.$3, size: 72, color: Colors.white70),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  IconButton(onPressed: () => _message(context, 'पोस्ट पसंद की गई (डेमो)।'), icon: const Icon(Icons.favorite_border)),
                  IconButton(onPressed: () => _message(context, 'कमेंट फीचर अगले चरण में आएगा।'), icon: const Icon(Icons.mode_comment_outlined)),
                  IconButton(onPressed: () => _message(context, 'शेयर फीचर अगले चरण में आएगा।'), icon: const Icon(Icons.share_outlined)),
                ]),
                Text(post.$2),
              ]),
            )
          ]),
        ),
      ],
    );
  }
}

class StoryBubble extends StatelessWidget {
  final String name;
  final Color color;
  const StoryBubble({super.key, required this.name, required this.color});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(right: 14),
    child: Column(children: [
      Container(
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: brand, width: 2)),
        child: CircleAvatar(radius: 27, backgroundColor: color.withOpacity(.3), child: Icon(Icons.person, color: color)),
      ),
      const SizedBox(height: 5),
      Text(name, style: const TextStyle(fontSize: 12)),
    ]),
  );
}

class ReelsPage extends StatelessWidget {
  const ReelsPage({super.key});
  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
      Icon(Icons.play_circle_fill, size: 82, color: brand),
      SizedBox(height: 12),
      Text('Reels', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      Text('यहाँ शॉर्ट वीडियो दिखाई देंगे।'),
      SizedBox(height: 8),
      Text('अभी यह शुरुआती डेमो स्क्रीन है।', style: TextStyle(color: Colors.white60)),
    ]),
  );
}

class CreatePage extends StatelessWidget {
  const CreatePage({super.key});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.add_a_photo_outlined, size: 72, color: brand),
        const SizedBox(height: 16),
        const Text('नई पोस्ट बनाएं', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('फोटो और वीडियो अपलोड की सुविधा अगले चरण में जोड़ी जाएगी।', textAlign: TextAlign.center),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: () => _message(context, 'अपलोड सुविधा अभी डेमो में उपलब्ध नहीं है।'),
          icon: const Icon(Icons.add),
          label: const Text('Create Post'),
        ),
      ]),
    ),
  );
}

class VideosPage extends StatelessWidget {
  const VideosPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Videos', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      for (int i = 1; i <= 3; i++)
        Card(
          color: const Color(0xFF1C1C29),
          child: ListTile(
            leading: Container(width: 72, height: 52, decoration: BoxDecoration(color: brand.withOpacity(.2), borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.play_arrow, color: Colors.white)),
            title: Text('Sample video $i'),
            subtitle: const Text('वीडियो प्लेयर अगले चरण में जोड़ा जाएगा'),
            trailing: const Icon(Icons.chevron_right),
          ),
        ),
    ],
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const SizedBox(height: 12),
      const Center(child: CircleAvatar(radius: 44, backgroundColor: brand, child: Icon(Icons.person, size: 48))),
      const SizedBox(height: 12),
      const Center(child: Text('Your Name', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
      const Center(child: Text('@your_username', style: TextStyle(color: Colors.white60))),
      const SizedBox(height: 20),
      const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        Stat(label: 'Posts', value: '0'),
        Stat(label: 'Followers', value: '0'),
        Stat(label: 'Following', value: '0'),
      ]),
      const SizedBox(height: 22),
      OutlinedButton(onPressed: () => _message(context, 'प्रोफाइल एडिट अगले चरण में आएगा.'), child: const Text('Edit Profile')),
      const SizedBox(height: 10),
      const Text('आपकी पोस्ट यहाँ दिखाई देंगी।', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
    ],
  );
}

class Stat extends StatelessWidget {
  final String label, value;
  const Stat({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    Text(label, style: const TextStyle(color: Colors.white60)),
  ]);
}
